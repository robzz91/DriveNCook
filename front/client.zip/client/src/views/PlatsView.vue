<template>
  <section class="page">
    <h1>Gestion des Plats</h1>

    <div class="columns">
      <div class="col">
        <PlatList @edit="edited = $event" />
      </div>
      <div class="col">
        <PlatForm :edited="edited" @saved="edited=null" @cancel="edited=null" />
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from "vue";
import PlatList from "@/components/PlatList.vue";
import PlatForm from "@/components/PlatForm.vue";

const edited = ref(null);
</script>

<style scoped>
.page { padding: 16px; }
.columns { display:grid; grid-template-columns: 2fr 1fr; gap: 16px; }
.col { min-width: 0; }
h1 { margin-bottom: 10px; }
</style>
