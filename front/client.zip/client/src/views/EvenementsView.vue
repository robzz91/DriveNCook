<template>
  <section class="page">
    <h1>Gestion des Événements</h1>

    <div class="columns">
      <div class="col">
        <EvenementList @edit="edited = $event" />
      </div>
      <div class="col">
        <EvenementForm :edited="edited" @saved="edited=null" @cancel="edited=null" />
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from "vue";
import EvenementList from "@/components/EvenementList.vue";
import EvenementForm from "@/components/EvenementForm.vue";

const edited = ref(null);
</script>

<style scoped>
.page { padding: 16px; }
.columns { display:grid; grid-template-columns: 2fr 1fr; gap: 16px; }
.col { min-width: 0; }
h1 { margin-bottom: 10px; }
</style>
