<template>
  <section class="page">
    <h1>Gestion des Commandes</h1>

    <div class="columns">
      <div class="col">
        <CommandeList @edit="edited = $event" />
      </div>
      <div class="col">
        <CommandeForm :edited="edited" @saved="edited=null" @cancel="edited=null" />
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from "vue";
import CommandeList from "@/components/CommandeList.vue";
import CommandeForm from "@/components/CommandeForm.vue";

const edited = ref(null);
</script>

<style scoped>
.page { padding: 16px; }
.columns { display:grid; grid-template-columns: 2fr 1fr; gap: 16px; }
.col { min-width: 0; }
h1 { margin-bottom: 10px; }
</style>
