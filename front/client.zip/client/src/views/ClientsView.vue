<template>
  <section class="page">
    <h1>Gestion des Clients</h1>

    <div class="columns">
      <div class="col">
        <ClientList @edit="edited = $event" />
      </div>
      <div class="col">
        <ClientForm :edited="edited" @saved="edited=null" @cancel="edited=null" />
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from "vue";
import ClientList from "@/components/ClientList.vue";
import ClientForm from "@/components/ClientForm.vue";

const edited = ref(null);
</script>

<style scoped>
.page { padding: 16px; }
.columns { display:grid; grid-template-columns: 2fr 1fr; gap: 16px; }
.col { min-width: 0; }
h1 { margin-bottom: 10px; }
</style>
