<template>
  <div class="home-container">
    <header class="hero">
      <h1>{{ $t("home.title") }}</h1>
      <p>{{ $t("home.subtitle") }}</p>
    </header>

    <section class="cards">
      <div class="card">
        <h2>{{ $t("home.clients") }}</h2>
        <p>{{ $t("home.clientsText") }}</p>
      </div>
      <div class="card">
        <h2>{{ $t("home.commandes") }}</h2>
        <p>{{ $t("home.commandesText") }}</p>
      </div>
      <div class="card">
        <h2>{{ $t("home.evenements") }}</h2>
        <p>{{ $t("home.evenementsText") }}</p>
      </div>
      <div class="card">
        <h2>{{ $t("home.plats") }}</h2>
        <p>{{ $t("home.platsText") }}</p>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>

<style scoped>
.home-container {
  padding: 2rem;
  background: #121212;
  color: #fff;
  min-height: 100vh;
}

.hero {
  text-align: center;
  margin-bottom: 2rem;
}

.hero h1 {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
  color: #ffcc00;
}

.hero p {
  font-size: 1.2rem;
  color: #ddd;
}

.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.card {
  background: #1e1e1e;
  padding: 1.5rem;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.4);
  transition: transform 0.2s;
}

.card:hover {
  transform: translateY(-5px);
}

.card h2 {
  color: #ffcc00;
  margin-bottom: 0.5rem;
}
</style>
