import { createRouter, createWebHistory } from "vue-router";
import HomeView from "@/views/HomeView.vue";   // ✅ corrige le nom
import ClientsView from "@/views/ClientsView.vue";
import CommandesView from "@/views/CommandesView.vue";
import EvenementsView from "@/views/EvenementsView.vue";
import PlatsView from "@/views/PlatsView.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", name: "home", component: HomeView },
    { path: "/clients", name: "clients", component: ClientsView },
    { path: "/commandes", name: "commandes", component: CommandesView },
    { path: "/evenements", name: "evenements", component: EvenementsView },
    { path: "/plats", name: "plats", component: PlatsView },
  ],
});

export default router;
