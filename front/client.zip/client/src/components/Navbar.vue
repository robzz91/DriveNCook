<template>
  <nav class="navbar">
    <div class="navbar-container">
      <!-- Logo -->
      <router-link to="/" class="logo">
        🍔 DriveNCook
      </router-link>

      <!-- Liens de navigation -->
      <ul class="nav-links">
        <li><router-link to="/clients" active-class="active">Clients</router-link></li>
        <li><router-link to="/plats" active-class="active">Plats</router-link></li>
        <li><router-link to="/commandes" active-class="active">Commandes</router-link></li>
        <li><router-link to="/evenements" active-class="active">Événements</router-link></li>
      </ul>
    </div>
  </nav>
</template>

<script setup>
// Pas besoin de script particulier ici, le router gère tout
</script>

<style scoped>
/* Navbar container */
.navbar {
  background: #1e1e2f;
  color: #fff;
  padding: 12px 24px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.3);
  position: sticky;
  top: 0;
  z-index: 1000;
}

/* Flex container */
.navbar-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* Logo */
.logo {
  font-size: 1.4rem;
  font-weight: bold;
  color: #ff9800;
  text-decoration: none;
  transition: color 0.3s;
}

.logo:hover {
  color: #ffc107;
}

/* Nav links */
.nav-links {
  list-style: none;
  display: flex;
  gap: 20px;
  margin: 0;
  padding: 0;
}

.nav-links li {
  display: inline;
}

/* Links */
.nav-links a {
  text-decoration: none;
  color: #ddd;
  font-weight: 500;
  padding: 6px 10px;
  border-radius: 6px;
  transition: background 0.3s, color 0.3s;
}

/* Hover effect */
.nav-links a:hover {
  background: #33334d;
  color: #fff;
}

/* Active link */
.active {
  background: #ff9800;
  color: #1e1e2f !important;
}
</style>
