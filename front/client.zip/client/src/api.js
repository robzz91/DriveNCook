// client/src/api.js
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000/api",
  headers: { "Content-Type": "application/json" },
  // Si ton API est sur un autre domaine et utilise des cookies:
  // withCredentials: true,
});

// (Optionnel) Intercepteur pour loguer les erreurs lisiblement
api.interceptors.response.use(
  (r) => r,
  (err) => {
    const msg =
      err.response?.data?.message ||
      err.response?.data?.error ||
      err.message ||
      "Erreur réseau";
    console.error("[API ERROR]", msg, err.response || "");
    return Promise.reject(err);
  }
);

export default api;
