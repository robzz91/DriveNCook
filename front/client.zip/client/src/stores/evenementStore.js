// client/src/stores/evenementStore.js
import { defineStore } from "pinia";
import api from "@/api";

export const useEvenementStore = defineStore("evenement", {
  state: () => ({
    list: [],
    current: null,
    loading: false,
    error: null,
  }),

  actions: {
    async fetchAll() {
      this.loading = true;
      this.error = null;
      try {
        const { data } = await api.get("/evenements");
        this.list = Array.isArray(data) ? data : data?.data ?? [];
      } catch (e) {
        this.error = e.response?.data?.message || "Erreur au chargement des événements";
      } finally {
        this.loading = false;
      }
    },

    async create(payload) {
      this.error = null;
      const { data } = await api.post("/evenements", payload);
      this.list.push(data);
      return data;
    },

    async update(id, payload) {
      this.error = null;
      const { data } = await api.put(`/evenements/${id}`, payload);
      const i = this.list.findIndex((ev) => String(ev.id) === String(id));
      if (i !== -1) this.list[i] = data;
      return data;
    },

    async remove(id) {
      this.error = null;
      await api.delete(`/evenements/${id}`);
      this.list = this.list.filter((ev) => String(ev.id) !== String(id));
    },
  },
});
