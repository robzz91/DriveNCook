// client/src/stores/platStore.js
import { defineStore } from "pinia";
import api from "@/api";

export const usePlatStore = defineStore("plat", {
  state: () => ({
    list: [],
    current: null,
    loading: false,
    error: null,
  }),

  actions: {
    async fetchAll() {
      this.loading = true;
      this.error = null;
      try {
        const { data } = await api.get("/plats");
        this.list = Array.isArray(data) ? data : data?.data ?? [];
      } catch (e) {
        this.error = e.response?.data?.message || "Erreur au chargement des plats";
      } finally {
        this.loading = false;
      }
    },

    async create(payload) {
      this.error = null;
      const { data } = await api.post("/plats", payload);
      this.list.push(data);
      return data;
    },

    async update(id, payload) {
      this.error = null;
      const { data } = await api.put(`/plats/${id}`, payload);
      const i = this.list.findIndex((p) => String(p.id) === String(id));
      if (i !== -1) this.list[i] = data;
      return data;
    },

    async remove(id) {
      this.error = null;
      await api.delete(`/plats/${id}`);
      this.list = this.list.filter((p) => String(p.id) !== String(id));
    },
  },
});
