// client/src/stores/clientStore.js
import { defineStore } from "pinia";
import api from "@/api";

export const useClientStore = defineStore("client", {
  state: () => ({
    list: [],
    current: null,
    loading: false,
    error: null,
  }),

  actions: {
    async fetchAll() {
      this.loading = true;
      this.error = null;
      try {
        const { data } = await api.get("/clients");
        this.list = Array.isArray(data) ? data : data?.data ?? [];
      } catch (e) {
        this.error = e.response?.data?.message || "Erreur au chargement des clients";
      } finally {
        this.loading = false;
      }
    },

    async fetchOne(id) {
      this.loading = true;
      this.error = null;
      try {
        const { data } = await api.get(`/clients/${id}`);
        this.current = data;
      } catch (e) {
        this.error = e.response?.data?.message || "Erreur au chargement du client";
      } finally {
        this.loading = false;
      }
    },

    async create(payload) {
      this.error = null;
      const { data } = await api.post("/clients", payload);
      // selon l'API, /clients renvoie l'objet créé
      this.list.push(data);
      return data;
    },

    async update(id, payload) {
      this.error = null;
      const { data } = await api.put(`/clients/${id}`, payload);
      const i = this.list.findIndex((c) => String(c.id) === String(id));
      if (i !== -1) this.list[i] = data;
      return data;
    },

    async remove(id) {
      this.error = null;
      await api.delete(`/clients/${id}`);
      this.list = this.list.filter((c) => String(c.id) !== String(id));
    },
  },
});
