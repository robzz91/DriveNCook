// client/src/stores/commandeStore.js
import { defineStore } from "pinia";
import api from "@/api";

export const useCommandeStore = defineStore("commande", {
  state: () => ({
    list: [],
    current: null,
    loading: false,
    error: null,
  }),

  actions: {
    async fetchAll() {
      this.loading = true;
      this.error = null;
      try {
        const { data } = await api.get("/commandes");
        this.list = Array.isArray(data) ? data : data?.data ?? [];
      } catch (e) {
        this.error = e.response?.data?.message || "Erreur au chargement des commandes";
      } finally {
        this.loading = false;
      }
    },

    async create(payload) {
      this.error = null;
      const { data } = await api.post("/commandes", payload);
      this.list.push(data);
      return data;
    },

    async update(id, payload) {
      this.error = null;
      const { data } = await api.put(`/commandes/${id}`, payload);
      const i = this.list.findIndex((o) => String(o.id) === String(id));
      if (i !== -1) this.list[i] = data;
      return data;
    },

    async remove(id) {
      this.error = null;
      await api.delete(`/commandes/${id}`);
      this.list = this.list.filter((o) => String(o.id) !== String(id));
    },
  },
});
